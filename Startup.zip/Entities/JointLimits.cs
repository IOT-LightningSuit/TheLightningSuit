﻿namespace WebApplication3.Entities
{
    public class JointLimits
    {
        public float startAngleX;
        //public float startAngleY;
        //public float startAngleZ;
        public float endAngleX;
        //public float endAngleY;
        //public float endAngleZ;
        public string errorMessage;

        public JointLimits(float sax, /*float say, float saz,*/ float eax, /*float eay, float eaz,*/ string err)
        {
            startAngleX = sax;
            endAngleX = eax;
            errorMessage = err;
        }
    }
}
