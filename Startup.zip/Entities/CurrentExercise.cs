﻿namespace WebApplication3.Entities
{
    public class CurrentExercise
    {
        public string CurrentEx { get; set; } = "Squat";
    }
}
